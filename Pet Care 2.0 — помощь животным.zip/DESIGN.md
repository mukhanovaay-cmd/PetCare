---
name: Pet Care
description: Цифровая экосистема помощи бездомным животным Казахстана — от «хочу помочь» до видимого результата
colors:
  teal: "#6CC3B5"
  teal-deep: "#2F7F74"
  teal-mist: "#DDF2EE"
  blossom: "#F6B5C4"
  blossom-deep: "#A33A5C"
  blossom-mist: "#FDE7EC"
  rose-heart: "#E57A97"
  sunbeam: "#F8DC8A"
  sunbeam-deep: "#6B4E08"
  sunbeam-mist: "#FEF5D8"
  sky: "#8EC9F5"
  sky-mist: "#E3F2FD"
  graphite: "#1E2A2B"
  graphite-soft: "#4A5755"
  morning-paper: "#FBFAF7"
  card-white: "#FFFFFF"
  path-line: "#ECE8E0"
typography:
  display:
    fontFamily: "Unbounded, Manrope, sans-serif"
    fontSize: "clamp(36px, 5.6vw, 64px)"
    fontWeight: 800
    lineHeight: 1.08
    letterSpacing: "-0.01em"
  headline:
    fontFamily: "Unbounded, Manrope, sans-serif"
    fontSize: "clamp(28px, 3.8vw, 44px)"
    fontWeight: 700
    lineHeight: 1.08
    letterSpacing: "-0.01em"
  title:
    fontFamily: "Unbounded, Manrope, sans-serif"
    fontSize: "19px"
    fontWeight: 600
    lineHeight: 1.25
  body:
    fontFamily: "Manrope, system-ui, sans-serif"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: 1.55
  lead:
    fontFamily: "Manrope, system-ui, sans-serif"
    fontSize: "17px"
    fontWeight: 400
    lineHeight: 1.55
  label:
    fontFamily: "Manrope, system-ui, sans-serif"
    fontSize: "13px"
    fontWeight: 700
    lineHeight: 1.3
rounded:
  chip: "10px"
  control: "14px"
  button: "18px"
  card: "26px"
  dialog: "30px"
  round: "50%"
spacing:
  xs: "8px"
  sm: "12px"
  md: "18px"
  lg: "22px"
  xl: "30px"
  band: "clamp(44px, 6vw, 92px)"
components:
  button-primary:
    backgroundColor: "{colors.graphite}"
    textColor: "{colors.card-white}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "0 24px"
    height: "52px"
  button-ghost:
    backgroundColor: "{colors.card-white}"
    textColor: "{colors.graphite}"
    rounded: "{rounded.button}"
    padding: "0 24px"
    height: "52px"
  button-small:
    backgroundColor: "{colors.graphite}"
    textColor: "{colors.card-white}"
    rounded: "{rounded.control}"
    padding: "0 16px"
    height: "44px"
  chip:
    backgroundColor: "{colors.blossom-mist}"
    textColor: "{colors.blossom-deep}"
    typography: "{typography.label}"
    rounded: "{rounded.chip}"
    padding: "5px 11px"
  filter-pill:
    backgroundColor: "{colors.card-white}"
    textColor: "{colors.graphite}"
    rounded: "22px"
    padding: "0 16px"
    height: "44px"
  filter-pill-active:
    backgroundColor: "{colors.graphite}"
    textColor: "{colors.morning-paper}"
  card:
    backgroundColor: "{colors.card-white}"
    textColor: "{colors.graphite}"
    rounded: "{rounded.card}"
    padding: "22px"
  input:
    backgroundColor: "{colors.morning-paper}"
    textColor: "{colors.graphite}"
    rounded: "{rounded.control}"
    padding: "10px 14px"
    height: "48px"
---

# Design System: Pet Care

## Overview

**Creative North Star: "Дорога домой"**

Pet Care рассказывает одну историю: путь животного от улицы к дому и путь человека от «хочу помочь» к реальному действию. Всё в системе движется вперёд. Дорога прорисовывается, сердца летят к приюту, питомец в профиле растёт. Последний отрезок пути всегда остаётся за человеком. Интерфейс тёплый и игривый, но не давит на жалость: вместо грустных фото он показывает надежду, небо, радугу и свет в окнах.

Плотность средняя: широкие цветные полосы во всю ширину, внутри них щедрые поля и карточки с крупным скруглением. Игривость держится на трёх вещах: мягких формах, рисованных питомцах и подтверждении каждого действия анимацией, XP и бейджами. Серьёзность держится на фактах: официальные контакты приютов, отчёты, источники и честные пометки «демо».

**Key Characteristics:**
- Пастельные поверхности teal, blossom, sunbeam и sky на светлой бумаге, графит для действий.
- Две гарнитуры: широкая Unbounded в заголовках, тёплая Manrope в тексте.
- Крупные скругления (26px у карточек) и круглые формы питомцев.
- Движение объясняет путь: прорисовка, путешествие по дороге, рост, свет.
- Каждое доброе дело получает ответ: +XP, перезвон, бейдж.

## Colors

Пастельная радуга надежды на тёплой бумаге; один тёмный графит отвечает за действия.

### Primary
- **Мятный teal** (teal): цвет пройденного пути, доверия и проверенных приютов. Линия «Дороги домой», иконки щита, активные этапы.
- **Глубокий teal** (teal-deep): текст и иконки на светлом фоне, где мятного не хватает по контрасту.

### Secondary
- **Цвет яблони** (blossom): тепло и забота. Сборы, сердца, крыша-домик в финале пути.
- **Сердечный розовый** (rose-heart): только избранное и сердечки, отклик на «лайк».

### Tertiary
- **Солнечный луч** (sunbeam): текущий шаг, награды, стрик, медали уровня.
- **Небо** (sky): атмосфера hopecore, фон историй и волонтёрства.

### Neutral
- **Графит** (graphite): основной текст и все главные кнопки действия.
- **Мягкий графит** (graphite-soft): второстепенный текст.
- **Утренняя бумага** (morning-paper): фон страницы.
- **Белая карточка** (card-white): поверхности карточек и диалогов.
- **Линия тропинки** (path-line): границы, разделители, ещё не пройденная дорога.

### Named Rules
**The Graphite Action Rule.** Главное действие на экране всегда графитовое. Пастель окрашивает поверхности, но никогда не главную кнопку.

**The Mist Surface Rule.** На пастельных полосах (mist-тона) текст всегда графитовый (#1E2A2B), в любой теме.

## Typography

**Display Font:** Unbounded (with Manrope, sans-serif)
**Body Font:** Manrope (with system-ui, sans-serif)

**Character:** Широкая округлая Unbounded звучит как вывеска доброго места. Manrope спокойная и разборчивая, ей доверяют факты, адреса и цифры. Обе поддерживают кириллицу и казахские буквы.

### Hierarchy
- **Display** (800, clamp 36–64px, 1.08): только главный заголовок первого экрана.
- **Headline** (700, clamp 28–44px, 1.08): заголовки разделов.
- **Title** (600, 19px, 1.25): заголовки карточек, имена этапов пути.
- **Body** (400, 16px, 1.55): основной текст, строка не длиннее 62ch.
- **Lead** (400, 17px, 1.55): подзаголовки разделов.
- **Label** (700, 13px): чипы, пометки, подписи. Без капса.

### Named Rules
**The No Eyebrow Rule.** Над заголовками нет надзаголовков и капса. Заголовок говорит сам за себя.

**The Tabular Facts Rule.** Суммы, XP и статистика набираются табличными цифрами.

## Layout

Страница состоит из полос во всю ширину с вертикальным отступом clamp(44px, 6vw, 92px) и горизонтальным max(5vw, 16px). Содержимое ограничено 1240px. Сетки строятся на `minmax(0, 1fr)`: питомцы `auto-fill` от 280px, сборы 4 → 2 → 1 колонки, приюты 3 → 2 → 1. «Дорога домой» делится на карту и панель (1.7fr / 1fr) и уходит в одну колонку ниже 960px. Ниже 620px выбор питомца становится горизонтальной лентой. Навигация липкая; ниже 1000px ссылки переносятся во вторую строку со скроллом.

## Elevation & Depth

Система почти плоская: глубина передаётся пастельными слоями и мягкими тенями только в ответ на состояние или для плавающих слоёв.

### Shadow Vocabulary
- **Hover lift** (`box-shadow: 0 14px 30px rgb(30 42 43 / .12)`): карточки при наведении.
- **Floating** (`box-shadow: 0 14px 34px rgb(30 42 43 / .25)`): кнопка ИИ-ассистента.
- **Overlay** (`box-shadow: 0 30px 80px rgb(0 0 0 / .25)`): диалоги, профиль, панель ИИ.

### Named Rules
**The Still Target Rule.** Элемент под курсором не сдвигается. При наведении двигается дочерний элемент (иконка, питомец), а сама карточка меняет только тень.

## Shapes

Мягкие, «детские» формы без острых углов: чипы 10px, мелкие кнопки 14px, кнопки 18px, карточки 26px, диалоги 30px; питомцы, аватары и медали круглые. Дорога — толстая скруглённая линия (16px, round cap); ещё не пройденная часть — пунктир из точек. Домик в конце пути — пунктирный контур, пока путь не завершён.

## Components

### Buttons
- **Shape:** скругление 18px (у малых 14px), высота 52px (малые 44px).
- **Primary:** графитовый фон, белый текст 16px/800.
- **Hover / Focus:** тень и лёгкое осветление без сдвига; при нажатии `scale(.96)`; фокус — кольцо teal 3px с отступом 3px.
- **Ghost:** полупрозрачный белый фон, тонкая графитовая рамка.

### Chips
- **Style:** blossom-mist фон, blossom-deep текст, 13px/700.
- **State:** фильтры-пилюли переключаются в графит при выборе (`aria-pressed`).

### Cards / Containers
- **Corner Style:** 26px.
- **Background:** белая карточка или пастельная mist-поверхность.
- **Shadow Strategy:** в покое без тени, тень только при наведении.
- **Border:** 1px path-line.
- **Internal Padding:** 22px.

### Inputs / Fields
- **Style:** фон утренней бумаги, рамка 1.5px path-line, скругление 14px, высота 48px, текст 16px.
- **Focus:** кольцо teal 3px.

### Navigation
- **Style:** липкая полоса с blur-подложкой, ссылки Manrope 14px/700, hover — teal-mist подложка. Справа переключатель языков RU/KZ/EN, кнопка звука и мини-профиль с растущим питомцем.

### Дорога домой (signature)
Извилистая дорога, по которой рисованный питомец идёт по этапам: улица → спасение → лечение → ждёт → дом. Пройденная часть прорисовывается teal-линией, питомец грустит до спасения и радуется после. Последний отрезок завершает только действие человека: домик наполняется цветом, в окнах зажигается свет.

### Растущий питомец (signature)
Щенок или котёнок в профиле: малыш → подросток (шарф sky) → взрослый (ошейник blossom с жетоном sunbeam). При пропуске дня грустит, но не исчезает. Новый уровень показывает медаль с радужным кольцом, 3D-разворотом и конфетти.

## Do's and Don'ts

### Do:
- **Do** делать главное действие графитовым, а пастель оставлять поверхностям.
- **Do** подтверждать каждое доброе дело откликом: +XP, перезвон, состояние кнопки.
- **Do** анимировать путь и состояние (прорисовка, путешествие, рост), используя `cubic-bezier(.16,1,.3,1)` для появлений.
- **Do** помечать демо-данные словом «ДЕМО» и указывать источники статистики.
- **Do** давать ссылки на официальные страницы приютов вместо любых платёжных реквизитов.

### Don't:
- **Don't** давить на жалость грустными фото и тёмными тонами.
- **Don't** двигать саму карточку или кнопку при наведении.
- **Don't** ставить надзаголовки и капс над заголовками.
- **Don't** вешать одинаковое «всплытие» на каждый раздел: одна авторская анимация на экран.
- **Don't** показывать выдуманные цифры как реальные.
